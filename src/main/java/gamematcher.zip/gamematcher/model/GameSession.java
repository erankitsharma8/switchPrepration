package gamematcher.model;

import gamematcher.model.enums.Enums;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class GameSession {
    private final String id;
    private final Enums.GameMode mode;
    private final Enums.GameLocation location;
    private final Set<Player> players;
    private final Enums.Rank requiredRank;
    private boolean isActive;

    public GameSession(String id, Enums.GameMode mode, Enums.GameLocation location,
                       Enums.Rank requiredRank) {
        this.id = id;
        this.mode = mode;
        this.location = location;
        this.requiredRank = requiredRank;
        this.players = ConcurrentHashMap.newKeySet();
        this.isActive = false;
    }

    public synchronized boolean addPlayers(Set<Player> newPlayers) {
        if (isActive || !canAcceptPlayers(newPlayers)) {
            return false;
        }

        newPlayers.forEach(player -> {
            players.add(player);
            player.setCurrentSession(this);
        });

        if (players.size() >= mode.getRequiredPlayers()) {
            isActive = true;
        }
        return true;
    }

    public synchronized void removePlayer(Player player) {
        players.remove(player);
        if (players.size() < mode.getRequiredPlayers()) {
            isActive = false;
        }
    }

    private boolean canAcceptPlayers(Set<Player> newPlayers) {
        // Check capacity
        if (players.size() + newPlayers.size() > mode.getRequiredPlayers()) {
            return false;
        }

        // Check rank compatibility
        if (requiredRank != null) {
            return newPlayers.stream().allMatch(p -> p.getRank() == requiredRank);
        }

        return true;
    }

    public boolean matchesMode(Enums.GameMode mode) {
        return this.mode == mode;
    }

    public boolean matchesLocation(Enums.GameLocation location) {
        return this.location == location;
    }

    public String getFormattedStatus() {
        String modeName = formatName(mode.name());
        String locationName = formatName(location.name());
        String playersList = players.stream()
                .map(Player::getName)
                .collect(Collectors.joining(", "));

        if (isActive) {
            return String.format("Playing %s game with players: %s in %s",
                    modeName, playersList, locationName);
        } else {
            return String.format("Waiting Game with players: %s", playersList);
        }
    }

    private String formatName(String input) {
        return Arrays.stream(input.split("_"))
                .map(word -> word.charAt(0) + word.substring(1).toLowerCase())
                .collect(Collectors.joining());
    }

    // Getters
    public String getId() { return id; }
    public Enums.GameMode getMode() { return mode; }
    public Enums.GameLocation getLocation() { return location; }
    public Set<Player> getPlayers() { return Collections.unmodifiableSet(players); }
    public Enums.Rank getRequiredRank() { return requiredRank; }
    public boolean isActive() { return isActive; }
}
